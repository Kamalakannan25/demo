package com.send.request.constants;

/**
 * @author Suchismita
 */
public class SenderRequestPortletKeys {

	public static final String SENDERREQUEST =
		"com_send_request_SenderRequestPortlet";

}