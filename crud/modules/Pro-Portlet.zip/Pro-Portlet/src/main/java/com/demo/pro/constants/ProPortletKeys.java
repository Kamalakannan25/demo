package com.demo.pro.constants;

/**
 * @author Suchismita
 */
public class ProPortletKeys {

	public static final String PRO =
		"com_demo_pro_ProPortlet";

}