package com.send.response.constants;

/**
 * @author Suchismita
 */
public class SenderResponsePortletKeys {

	public static final String SENDERRESPONSE =
		"com_send_response_SenderResponsePortlet";

}