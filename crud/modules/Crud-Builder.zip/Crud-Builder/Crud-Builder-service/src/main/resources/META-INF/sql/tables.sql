create table Sports_Sports (
	uuid_ VARCHAR(75) null,
	sportsId LONG not null primary key,
	sportsName VARCHAR(75) null,
	description VARCHAR(75) null
);