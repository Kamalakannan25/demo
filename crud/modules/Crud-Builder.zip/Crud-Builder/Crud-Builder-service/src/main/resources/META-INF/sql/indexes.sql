create index IX_E159BB63 on Sports_Sports (sportsName[$COLUMN_LENGTH:75$]);
create index IX_E72655CF on Sports_Sports (uuid_[$COLUMN_LENGTH:75$]);